package pages.actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import pages.locators.LoanHomePageLocators;
import utils.SeleniumDriver;

public class LoanHomePageActions {
	
	LoanHomePageLocators carsGuideHomePageLocators=null;
	public LoanHomePageActions()
	{
		
		this.carsGuideHomePageLocators=new LoanHomePageLocators();
		PageFactory.initElements(SeleniumDriver.getDriver(), carsGuideHomePageLocators);
	}
	
	public void moveToCarsForSaleMenu()
	{
		Actions action= new Actions(SeleniumDriver.getDriver());
		action.moveToElement(carsGuideHomePageLocators.carsForSaleLink).perform();
	}
	public void clickOnSearchCarsMenu()
	{
		//moveToCarsForSaleMenu();
		carsGuideHomePageLocators.searchCarsLink.click();
		
	}
	public void clickOnUsedSearchCarsMenu()
	{
		//moveToCarsForSaleMenu();
		carsGuideHomePageLocators.usedSearchCarsLink.click();
		
	}

}
