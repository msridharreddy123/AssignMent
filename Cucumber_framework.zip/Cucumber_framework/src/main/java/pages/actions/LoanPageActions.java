package pages.actions;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;



import pages.locators.LoanPageLocators;
import utils.SeleniumDriver;

public class LoanPageActions {
	
	//WebDriver driver=null;
	
	LoanPageLocators LoanPageLocators=null;
	public  LoanPageActions()
	{
		//this.driver=driver;
		this.LoanPageLocators= new LoanPageLocators();
		PageFactory.initElements(SeleniumDriver.getDriver(), LoanPageLocators);
	}

	public void clickApplicationType(String carBrand)
	{
		
		//SeleniumDriver.getDriver().findElement(By.xpath(".//*[@id='makes']")).click();
		SeleniumDriver.getDriver().findElement(By.xpath("//input[@id='application_type_single']")).click();
		
		
	}
	
	public void selectNumberOfDependants(String noofdependants)
	{
		//SeleniumDriver.getDriver().findElement(By.xpath(".//*[@id='models']")).click();
		SeleniumDriver.getDriver().findElement(By.xpath("//select[@title='Number of dependants']")).click();
		Select noOfDependants=new Select(LoanPageLocators.selectModelDropDown);
		noOfDependants.selectByVisibleText(noofdependants);
	}
	public void clickHometoLiveIn(String hometolivein)
	{
		//SeleniumDriver.getDriver().findElement(By.xpath(".//*[@id='locations']")).click();
		SeleniumDriver.getDriver().findElement(By.xpath(".//*[@id='block-system-main']/div/div/div/div/div/form")).click();
		
	}
	public void selectPrice(String price)
	{
		//SeleniumDriver.getDriver().findElement(By.xpath(".//*[@id='price-max']")).click();
		SeleniumDriver.getDriver().findElement(By.xpath(".//*[@id='block-system-main']/div/div/div/div/div/form")).sendKeys("$80000");
		Select selectPrice=new Select(LoanPageLocators.priceList);
		selectPrice.selectByVisibleText(price);
	}
	
	public void clickOnFindMyNextCarButton()
	{
		SeleniumDriver.getDriver().findElement(By.xpath(".//*[@id='block-system-main']/div/div/div/div/div/form")).click();
		LoanPageLocators.findMyNextCarButton.click();
		
	}
	
	
	
}
