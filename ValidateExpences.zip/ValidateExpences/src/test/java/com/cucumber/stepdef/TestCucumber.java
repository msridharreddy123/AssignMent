package com.cucumber.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestCucumber {
	WebDriver driver;

    @Given("^I am on the login page of the demo application$")
    public void open_the_Browser_and_launch_the_application() throws Throwable {
        System.setProperty("webdriver.chrome.driver", "Path of Chrome.exe file");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http:///");
        System.out.println("Login page of the application is opened.");
    }

    @When("^User enter expences and password $")
    public void enter_the_Username_and_Password() throws Throwable {

        driver.findElement(By.name("uid")).sendKeys("username");
        driver.findElement(By.name("password")).sendKeys("password");
        System.out.println("Username and password entered in the application");
        }

        @Then("^User should login to the home page successfully$")
        public void successful_login() throws Throwable {
            driver.getTitle().contains("Title");
            System.out.println("Matching the title of the page after successful login.");
        }

        @After
        public void Close_the_browser() throws Throwable {
            driver.close();
            System.out.println("Closes the browser opened through selenium");
        }

}
